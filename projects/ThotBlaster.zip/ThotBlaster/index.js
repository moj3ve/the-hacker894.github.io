const Discord = require('discord.js')
const client = new Discord.Client({autoReconnect:true})
const RichEmbed = require('discord.js').RichEmbed
const Attachment = require('discord.js').Attachment
const config = require('./config.json')
const token = config.token
const prefix = config.prefix

client.on("ready", () => {
    console.log('[LOGGED ON] ' + client.user.tag)
})
client.on("message", (message) => {
    var msg = message.content.toUpperCase()
    if(msg.includes('AM THOT')) {
        message.channel.send({ files: [new Attachment('thotblaster.png', 'thotblaster.png')] })
        function blastThot() {
            if(message.member.kickable) {
            message.member.kick('Thots are not allowed')
                message.channel.send('**THOT BLASTED**')
            
            } else {
                message.channel.send('**THOT COULD NOT BE BLASTED**')
            }
            return;
        }
        setTimeout(blastThot, 5000)
        return;
    }
    if(msg.includes('AM A THAT')) {
        message.channel.send({ files: [new Attachment('thotblaster.png', 'thotblaster.png')] })
        function blastThot() {
            if(message.member.kickable) {
            message.member.kick('Thots are not allowed')
                message.channel.send('**THOT BLASTED**')
            
            } else {
                message.channel.send('**THOT COULD NOT BE BLASTED**')
            }
            return;
        }
        setTimeout(blastThot, 5000)
        return;
    }
    if(msg.includes('I THOT')) {
        message.channel.send({ files: [new Attachment('thotblaster.png', 'thotblaster.png')] })
        function blastThot() {
            if(message.member.kickable) {
            message.member.kick('Thots are not allowed')
                message.channel.send('**THOT BLASTED**')
            
            } else {
                message.channel.send('**THOT COULD NOT BE BLASTED**')
            }
            return;
        }
        setTimeout(blastThot, 5000)
        return;
    }
    if(msg.includes('I AM THOT')) {
        message.channel.send({ files: [new Attachment('thotblaster.png', 'thotblaster.png')] })
        function blastThot() {
            if(message.member.kickable) {
            message.member.kick('Thots are not allowed')
                message.channel.send('**THOT BLASTED**')
            
            } else {
                message.channel.send('**THOT COULD NOT BE BLASTED**')
            }
            return;
        }
        setTimeout(blastThot, 5000)
        return;
    }
    if(msg.includes('THOT I AM')) {
        message.channel.send({ files: [new Attachment('thotblaster.png', 'thotblaster.png')] })
        function blastThot() {
            if(message.member.kickable) {
            message.member.kick('Thots are not allowed')
                message.channel.send('**THOT BLASTED**')
            
            } else {
                message.channel.send('**THOT COULD NOT BE BLASTED**')
            }
            return;
        }
        setTimeout(blastThot, 5000)
        return;
    }

})

client.login(token)